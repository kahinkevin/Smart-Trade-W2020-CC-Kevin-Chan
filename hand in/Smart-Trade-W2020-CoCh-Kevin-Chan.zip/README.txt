Please make sure that you have Python 3+ installed and added to your path.

Also make sure that you have installed these python dependencies :
	- pandas
	- selenium
	- urllib

__________________________________________________

Run the script :
	python fetch.py


__________________________________________________

Example of configuration (my configuration) :
	Windows 10
	Python 3.6.5 Anaconda
	pandas==0.23.0
	selenium 3.141.0
	urllib3==1.22